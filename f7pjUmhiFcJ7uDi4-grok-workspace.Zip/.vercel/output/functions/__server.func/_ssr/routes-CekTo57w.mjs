import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Play, i as Shuffle, n as Trash2, r as Square } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CekTo57w.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TRACKS = [
	{
		id: "kick",
		name: "باص",
		hint: "طبلة"
	},
	{
		id: "snare",
		name: "سنير",
		hint: "جانبي"
	},
	{
		id: "hat",
		name: "هات",
		hint: "مغلق"
	},
	{
		id: "perc",
		name: "إيقاع",
		hint: "تصفيق"
	}
];
function emptyPattern() {
	return Array.from({ length: 4 }, () => Array(16).fill(false));
}
function withSteps(steps) {
	const pattern = emptyPattern();
	steps.forEach((row, track) => {
		for (const step of row) pattern[track][step] = true;
	});
	return pattern;
}
function presetNabd() {
	return withSteps([
		[
			0,
			8,
			10
		],
		[4, 12],
		[
			0,
			2,
			4,
			6,
			8,
			10,
			12,
			14
		],
		[6, 14]
	]);
}
function presetHouse() {
	return withSteps([
		[
			0,
			4,
			8,
			12
		],
		[4, 12],
		[
			0,
			2,
			4,
			6,
			8,
			10,
			12,
			14
		],
		[4, 12]
	]);
}
function presetTrap() {
	return withSteps([
		[
			0,
			3,
			6,
			10
		],
		[4, 12],
		[
			0,
			2,
			4,
			6,
			8,
			10,
			12,
			13,
			14,
			15
		],
		[12, 14]
	]);
}
function presetBreak() {
	return withSteps([
		[
			0,
			3,
			6,
			10
		],
		[
			4,
			7,
			12,
			15
		],
		[
			0,
			2,
			4,
			5,
			6,
			8,
			10,
			12,
			13,
			14
		],
		[2, 11]
	]);
}
var PRESETS = [
	{
		id: "nabd",
		name: "نبض",
		build: presetNabd
	},
	{
		id: "house",
		name: "هاوس",
		build: presetHouse
	},
	{
		id: "trap",
		name: "تراب",
		build: presetTrap
	},
	{
		id: "break",
		name: "بريك",
		build: presetBreak
	}
];
function randomPattern() {
	const pattern = emptyPattern();
	pattern[0][0] = true;
	for (const step of [
		3,
		6,
		7,
		8,
		10,
		11,
		14
	]) if (Math.random() < .4) pattern[0][step] = true;
	pattern[1][4] = true;
	pattern[1][12] = true;
	if (Math.random() < .45) pattern[1][Math.random() < .5 ? 7 : 15] = true;
	for (let step = 0; step < 16; step++) {
		const offbeat = step % 2 === 1;
		if (Math.random() < (offbeat ? .74 : .42)) pattern[2][step] = true;
	}
	pattern[2][0] = true;
	pattern[2][8] = true;
	for (let step = 0; step < 16; step++) if (Math.random() < .2 && !pattern[0][step]) pattern[3][step] = true;
	if (!pattern[3].some(Boolean)) pattern[3][6] = true;
	return pattern;
}
function patternsEqual(a, b) {
	return a.every((row, track) => row.every((on, step) => on === b[track]?.[step]));
}
function isPattern(value) {
	if (!Array.isArray(value) || value.length !== 4) return false;
	return value.every((row) => Array.isArray(row) && row.length === 16 && row.every((cell) => typeof cell === "boolean"));
}
var STORAGE_KEY = "nabd-kit-v1";
function loadKit() {
	if (typeof localStorage === "undefined") return null;
	try {
		const raw = localStorage.getItem(STORAGE_KEY);
		if (!raw) return null;
		const data = JSON.parse(raw);
		if (!isPattern(data.pattern)) return null;
		const bpm = clamp(Number(data.bpm), 60, 180, 96);
		const swing = clamp(Number(data.swing), 0, 100, 0);
		const volume = clamp(Number(data.volume), 0, 100, 80);
		return {
			pattern: data.pattern,
			bpm,
			swing,
			volume
		};
	} catch {
		return null;
	}
}
function saveKit(settings) {
	try {
		localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
	} catch {}
}
function clamp(value, min, max, fallback) {
	if (!Number.isFinite(value)) return fallback;
	return Math.min(max, Math.max(min, Math.round(value)));
}
var LOOKAHEAD = .14;
var DrumMachine$1 = class {
	ctx = null;
	master = null;
	noise = null;
	timer = 0;
	raf = 0;
	nextTime = 0;
	stepIndex = 0;
	playing = false;
	pattern = Array.from({ length: 4 }, () => Array(16).fill(false));
	bpm = 96;
	swing = 0;
	volume = .8;
	displayStep = null;
	queue = [];
	listeners = /* @__PURE__ */ new Set();
	subscribe(listener) {
		this.listeners.add(listener);
		listener(this.displayStep, this.playing);
		return () => this.listeners.delete(listener);
	}
	setPattern(pattern) {
		this.pattern = pattern;
	}
	setBpm(bpm) {
		this.bpm = bpm;
	}
	setSwing(swing) {
		this.swing = swing;
	}
	setVolume(volume) {
		this.volume = volume;
		if (this.master && this.ctx) this.master.gain.setTargetAtTime(volume, this.ctx.currentTime, .02);
	}
	get playingNow() {
		return this.playing;
	}
	unlock() {
		this.ensure();
	}
	preview(track) {
		const ctx = this.ensure();
		this.hit(track, ctx.currentTime);
	}
	play() {
		const ctx = this.ensure();
		if (this.playing) {
			this.stepIndex = 0;
			this.nextTime = ctx.currentTime + .05;
			this.queue = [];
			return;
		}
		this.playing = true;
		this.stepIndex = 0;
		this.nextTime = ctx.currentTime + .05;
		this.queue = [];
		this.timer = window.setInterval(() => this.schedule(), 25);
		this.schedule();
		this.pump();
		this.emit();
	}
	stop() {
		this.playing = false;
		if (this.timer) window.clearInterval(this.timer);
		this.timer = 0;
		if (this.raf) cancelAnimationFrame(this.raf);
		this.raf = 0;
		this.queue = [];
		this.displayStep = null;
		this.emit();
	}
	dispose() {
		this.stop();
	}
	emit() {
		for (const listener of this.listeners) listener(this.displayStep, this.playing);
	}
	ensure() {
		if (!this.ctx) {
			const ctx = new AudioContext();
			const master = ctx.createGain();
			master.gain.value = this.volume;
			const comp = ctx.createDynamicsCompressor();
			comp.threshold.value = -14;
			comp.knee.value = 16;
			comp.ratio.value = 3.2;
			comp.attack.value = .004;
			comp.release.value = .18;
			master.connect(comp);
			comp.connect(ctx.destination);
			this.ctx = ctx;
			this.master = master;
			this.noise = makeNoise(ctx);
		}
		if (this.ctx.state === "suspended") this.ctx.resume();
		return this.ctx;
	}
	schedule() {
		const ctx = this.ctx;
		if (!ctx || !this.playing) return;
		while (this.nextTime < ctx.currentTime + LOOKAHEAD) {
			const step = this.stepIndex;
			const when = this.nextTime;
			for (let track = 0; track < 4; track++) if (this.pattern[track]?.[step]) this.hit(track, when);
			this.queue.push({
				step,
				time: when
			});
			this.nextTime += stepDuration(step, this.bpm, this.swing);
			this.stepIndex = (step + 1) % 16;
		}
	}
	pump = () => {
		if (!this.playing || !this.ctx) return;
		const now = this.ctx.currentTime;
		let step = null;
		while (this.queue.length && this.queue[0].time <= now + .02) step = this.queue.shift().step;
		if (step !== null && step !== this.displayStep) {
			this.displayStep = step;
			this.emit();
		}
		this.raf = requestAnimationFrame(this.pump);
	};
	hit(track, time) {
		if (track === 0) this.kick(time);
		else if (track === 1) this.snare(time);
		else if (track === 2) this.hat(time);
		else this.clap(time);
	}
	kick(time) {
		const ctx = this.ctx;
		const osc = ctx.createOscillator();
		const gain = ctx.createGain();
		osc.type = "sine";
		osc.frequency.setValueAtTime(164, time);
		osc.frequency.exponentialRampToValueAtTime(48, time + .1);
		gain.gain.setValueAtTime(1e-4, time);
		gain.gain.exponentialRampToValueAtTime(.95, time + .006);
		gain.gain.exponentialRampToValueAtTime(.001, time + .4);
		osc.connect(gain);
		gain.connect(this.master);
		osc.start(time);
		osc.stop(time + .42);
		const click = ctx.createOscillator();
		const clickGain = ctx.createGain();
		click.type = "triangle";
		click.frequency.setValueAtTime(980, time);
		clickGain.gain.setValueAtTime(.16, time);
		clickGain.gain.exponentialRampToValueAtTime(.001, time + .016);
		click.connect(clickGain);
		clickGain.connect(this.master);
		click.start(time);
		click.stop(time + .03);
	}
	snare(time) {
		const ctx = this.ctx;
		const noise = ctx.createBufferSource();
		noise.buffer = this.noise;
		const highpass = ctx.createBiquadFilter();
		highpass.type = "highpass";
		highpass.frequency.value = 1600;
		const gain = ctx.createGain();
		gain.gain.setValueAtTime(.62, time);
		gain.gain.exponentialRampToValueAtTime(.001, time + .18);
		noise.connect(highpass);
		highpass.connect(gain);
		gain.connect(this.master);
		noise.start(time);
		noise.stop(time + .2);
		const body = ctx.createOscillator();
		const bodyGain = ctx.createGain();
		body.type = "triangle";
		body.frequency.setValueAtTime(196, time);
		body.frequency.exponentialRampToValueAtTime(130, time + .08);
		bodyGain.gain.setValueAtTime(.4, time);
		bodyGain.gain.exponentialRampToValueAtTime(.001, time + .12);
		body.connect(bodyGain);
		bodyGain.connect(this.master);
		body.start(time);
		body.stop(time + .14);
	}
	hat(time) {
		const ctx = this.ctx;
		const bus = ctx.createGain();
		bus.gain.value = .5;
		const highpass = ctx.createBiquadFilter();
		highpass.type = "highpass";
		highpass.frequency.value = 7e3;
		const band = ctx.createBiquadFilter();
		band.type = "bandpass";
		band.frequency.value = 1e4;
		band.Q.value = .7;
		const gain = ctx.createGain();
		gain.gain.setValueAtTime(.9, time);
		gain.gain.exponentialRampToValueAtTime(.001, time + .05);
		bus.connect(highpass);
		highpass.connect(band);
		band.connect(gain);
		gain.connect(this.master);
		for (const ratio of [
			2,
			3,
			4.16,
			5.43,
			6.79,
			8.21
		]) {
			const osc = ctx.createOscillator();
			osc.type = "square";
			osc.frequency.value = 40 * ratio;
			osc.connect(bus);
			osc.start(time);
			osc.stop(time + .07);
		}
		const noise = ctx.createBufferSource();
		noise.buffer = this.noise;
		const noiseHighpass = ctx.createBiquadFilter();
		noiseHighpass.type = "highpass";
		noiseHighpass.frequency.value = 8e3;
		const noiseGain = ctx.createGain();
		noiseGain.gain.setValueAtTime(.4, time);
		noiseGain.gain.exponentialRampToValueAtTime(.001, time + .04);
		noise.connect(noiseHighpass);
		noiseHighpass.connect(noiseGain);
		noiseGain.connect(this.master);
		noise.start(time);
		noise.stop(time + .06);
	}
	clap(time) {
		const ctx = this.ctx;
		for (const burst of [
			{
				offset: 0,
				gain: .38,
				decay: .03
			},
			{
				offset: .012,
				gain: .42,
				decay: .03
			},
			{
				offset: .025,
				gain: .55,
				decay: .14
			}
		]) {
			const at = time + burst.offset;
			const noise = ctx.createBufferSource();
			noise.buffer = this.noise;
			const band = ctx.createBiquadFilter();
			band.type = "bandpass";
			band.frequency.value = 1500;
			band.Q.value = .85;
			const highpass = ctx.createBiquadFilter();
			highpass.type = "highpass";
			highpass.frequency.value = 900;
			const gain = ctx.createGain();
			gain.gain.setValueAtTime(burst.gain, at);
			gain.gain.exponentialRampToValueAtTime(.001, at + burst.decay);
			noise.connect(band);
			band.connect(highpass);
			highpass.connect(gain);
			gain.connect(this.master);
			noise.start(at);
			noise.stop(at + burst.decay + .02);
		}
	}
};
function stepDuration(step, bpm, swing) {
	const pair = 60 / bpm / 4 * 2;
	const ratio = .5 + swing / 100 * .25;
	return step % 2 === 0 ? pair * ratio : pair * (1 - ratio);
}
function makeNoise(ctx) {
	const length = ctx.sampleRate * 2;
	const buffer = ctx.createBuffer(1, length, ctx.sampleRate);
	const data = buffer.getChannelData(0);
	for (let i = 0; i < length; i++) data[i] = Math.random() * 2 - 1;
	return buffer;
}
var GROUPS = [
	0,
	1,
	2,
	3
];
function DrumMachine() {
	const engineRef = (0, import_react.useRef)(null);
	const scrollerRef = (0, import_react.useRef)(null);
	const [pattern, setPattern] = (0, import_react.useState)(presetNabd);
	const [bpm, setBpm] = (0, import_react.useState)(96);
	const [swing, setSwing] = (0, import_react.useState)(0);
	const [volume, setVolume] = (0, import_react.useState)(80);
	const [step, setStep] = (0, import_react.useState)(null);
	const [playing, setPlaying] = (0, import_react.useState)(false);
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	const patternRef = (0, import_react.useRef)(pattern);
	const bpmRef = (0, import_react.useRef)(bpm);
	const swingRef = (0, import_react.useRef)(swing);
	const volumeRef = (0, import_react.useRef)(volume);
	patternRef.current = pattern;
	bpmRef.current = bpm;
	swingRef.current = swing;
	volumeRef.current = volume;
	(0, import_react.useEffect)(() => {
		const engine = new DrumMachine$1();
		engineRef.current = engine;
		const saved = loadKit();
		if (saved) {
			setPattern(saved.pattern);
			setBpm(saved.bpm);
			setSwing(saved.swing);
			setVolume(saved.volume);
			engine.setPattern(saved.pattern);
			engine.setBpm(saved.bpm);
			engine.setSwing(saved.swing);
			engine.setVolume(saved.volume / 100);
		} else {
			engine.setPattern(patternRef.current);
			engine.setBpm(bpmRef.current);
			engine.setSwing(swingRef.current);
			engine.setVolume(volumeRef.current / 100);
		}
		const unsubscribe = engine.subscribe((nextStep, nextPlaying) => {
			setStep(nextStep);
			setPlaying(nextPlaying);
		});
		const onKey = (event) => {
			if (event.code !== "Space") return;
			const target = event.target;
			if (target instanceof HTMLElement) {
				const tag = target.tagName;
				if (tag === "INPUT" || tag === "TEXTAREA" || tag === "BUTTON") return;
			}
			event.preventDefault();
			if (engine.playingNow) engine.stop();
			else engine.play();
		};
		window.addEventListener("keydown", onKey);
		setHydrated(true);
		return () => {
			unsubscribe();
			window.removeEventListener("keydown", onKey);
			engine.dispose();
			engineRef.current = null;
		};
	}, []);
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		saveKit({
			pattern,
			bpm,
			swing,
			volume
		});
	}, [
		hydrated,
		pattern,
		bpm,
		swing,
		volume
	]);
	(0, import_react.useEffect)(() => {
		if (step === null) return;
		const scroller = scrollerRef.current;
		const marker = scroller?.querySelector(`[data-step-marker="${step}"]`);
		if (!scroller || !marker) return;
		if (scroller.scrollWidth <= scroller.clientWidth + 2) return;
		const mark = marker.getBoundingClientRect();
		const view = scroller.getBoundingClientRect();
		const laneLeft = scroller.querySelector(".lane:not(.lane-spacer)")?.getBoundingClientRect().left ?? view.right;
		const hiddenLeft = mark.left < view.left + 6;
		const hiddenRight = mark.right > laneLeft - 4;
		if (hiddenLeft || hiddenRight) scroller.scrollLeft += mark.left - view.left - 16;
	}, [step]);
	function commit(next) {
		setPattern(next);
		engineRef.current?.setPattern(next);
	}
	function toggle(track, index) {
		engineRef.current?.preview(track);
		const next = pattern.map((row) => row.slice());
		next[track][index] = !next[track][index];
		commit(next);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "shell",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "top",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "brand-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "led",
					"data-live": playing,
					"data-beat": playing && step !== null && step % 4 === 0,
					"aria-hidden": "true"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "brand",
					children: "نبض"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "lede",
				children: "آلة طبول بشبكة من ست عشرة خطوة. اضغط الخانة لتسمعها وتثبّتها، واسم الآلة لتجربتها وحدها."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "readout",
				"aria-live": "polite",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "readout-label",
					children: playing ? "الخطوة" : "متوقف"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "readout-num",
					children: step === null ? "–" : String(step + 1).padStart(2, "0")
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "chassis",
			"aria-label": "جهاز التسلسل",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "transport",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "btn btn-play",
							"data-active": playing,
							"aria-pressed": playing,
							onClick: () => engineRef.current?.play(),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
								"aria-hidden": "true",
								size: 18,
								fill: "currentColor"
							}), "تشغيل"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "btn btn-stop",
							onClick: () => engineRef.current?.stop(),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Square, {
								"aria-hidden": "true",
								size: 16,
								fill: "currentColor"
							}), "إيقاف"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "transport-gap",
							"aria-hidden": "true"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "btn btn-ghost",
							onClick: () => commit(randomPattern()),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shuffle, {
								"aria-hidden": "true",
								size: 18
							}), "نمط عشوائي"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "btn btn-ghost",
							onClick: () => commit(emptyPattern()),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {
								"aria-hidden": "true",
								size: 18
							}), "مسح النمط"]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "controls",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "control",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "control-name",
									children: "السرعة"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "range",
									min: 60,
									max: 180,
									step: 1,
									value: bpm,
									"aria-valuemin": 60,
									"aria-valuemax": 180,
									"aria-valuenow": bpm,
									"aria-label": "السرعة",
									onChange: (event) => {
										const next = Number(event.target.value);
										setBpm(next);
										engineRef.current?.setBpm(next);
									}
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "control-value",
									children: bpm
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "control",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "control-name",
									children: "السوينغ"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "range",
									min: 0,
									max: 100,
									step: 1,
									value: swing,
									"aria-valuemin": 0,
									"aria-valuemax": 100,
									"aria-valuenow": swing,
									"aria-describedby": "swing-note",
									"aria-label": "السوينغ",
									onChange: (event) => {
										const next = Number(event.target.value);
										setSwing(next);
										engineRef.current?.setSwing(next);
									}
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "control-value",
									children: [swing, "%"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "control-note",
									id: "swing-note",
									children: "يؤخّر الخطوات الزوجية عن النبض."
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "control",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "control-name",
									children: "الصوت"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "range",
									min: 0,
									max: 100,
									step: 1,
									value: volume,
									"aria-label": "الصوت",
									onChange: (event) => {
										const next = Number(event.target.value);
										setVolume(next);
										engineRef.current?.setVolume(next / 100);
									}
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "control-value",
									children: volume
								})
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "presets",
					role: "group",
					"aria-label": "أنماط جاهزة",
					children: PRESETS.map((preset) => {
						const built = preset.build();
						const active = patternsEqual(pattern, built);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "chip",
							"data-active": active,
							"aria-pressed": active,
							onClick: () => commit(built),
							children: preset.name
						}, preset.id);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "scroll-hint",
					children: "اسحب الشبكة لرؤية الخطوات الست عشرة."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "board-scroll",
					dir: "ltr",
					ref: scrollerRef,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "board",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "track",
							"aria-hidden": "true",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "groups",
								children: GROUPS.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "group",
									children: GROUPS.map((offset) => {
										const index = group * 4 + offset;
										return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "ruler-cell",
											"data-step-marker": index,
											"data-beat": index % 4 === 0,
											"data-now": step === index,
											children: index + 1
										}, index);
									})
								}, group))
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "lane lane-spacer" })]
						}), TRACKS.map((track, trackIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "track",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "groups",
								children: GROUPS.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "group",
									role: "group",
									"aria-label": `${track.name} ${group + 1}`,
									children: GROUPS.map((offset) => {
										const index = group * 4 + offset;
										const on = pattern[trackIndex][index];
										return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "pad",
											"data-on": on,
											"data-now": step === index,
											"data-beat": index % 4 === 0,
											"aria-pressed": on,
											"aria-label": `${track.name}، الخطوة ${index + 1}${on ? "، مفعّلة" : ""}`,
											onClick: () => toggle(trackIndex, index)
										}, index);
									})
								}, group))
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "lane",
								dir: "rtl",
								onClick: () => engineRef.current?.preview(trackIndex),
								"aria-label": `جرّب ${track.name}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "lane-name",
									children: track.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "lane-hint",
									children: track.hint
								})]
							})]
						}, track.id))]
					})
				})
			]
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DrumMachine, {});
}
//#endregion
export { Home as component };
