import { STEPS, TRACK_COUNT, type Pattern } from "@/lib/drums/pattern";

type Listener = (step: number | null, playing: boolean) => void;

const LOOKAHEAD = 0.14;

export class DrumMachine {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private noise: AudioBuffer | null = null;
  private timer = 0;
  private raf = 0;
  private nextTime = 0;
  private stepIndex = 0;
  private playing = false;
  private pattern: Pattern = Array.from({ length: TRACK_COUNT }, () =>
    Array<boolean>(STEPS).fill(false),
  );
  private bpm = 96;
  private swing = 0;
  private volume = 0.8;
  private displayStep: number | null = null;
  private queue: { step: number; time: number }[] = [];
  private listeners = new Set<Listener>();

  subscribe(listener: Listener) {
    this.listeners.add(listener);
    listener(this.displayStep, this.playing);
    return () => this.listeners.delete(listener);
  }

  setPattern(pattern: Pattern) {
    this.pattern = pattern;
  }

  setBpm(bpm: number) {
    this.bpm = bpm;
  }

  setSwing(swing: number) {
    this.swing = swing;
  }

  setVolume(volume: number) {
    this.volume = volume;
    if (this.master && this.ctx) {
      this.master.gain.setTargetAtTime(volume, this.ctx.currentTime, 0.02);
    }
  }

  get playingNow() {
    return this.playing;
  }

  unlock() {
    this.ensure();
  }

  preview(track: number) {
    const ctx = this.ensure();
    this.hit(track, ctx.currentTime);
  }

  play() {
    const ctx = this.ensure();
    if (this.playing) {
      this.stepIndex = 0;
      this.nextTime = ctx.currentTime + 0.05;
      this.queue = [];
      return;
    }
    this.playing = true;
    this.stepIndex = 0;
    this.nextTime = ctx.currentTime + 0.05;
    this.queue = [];
    this.timer = window.setInterval(() => this.schedule(), 25);
    this.schedule();
    this.pump();
    this.emit();
  }

  stop() {
    this.playing = false;
    if (this.timer) window.clearInterval(this.timer);
    this.timer = 0;
    if (this.raf) cancelAnimationFrame(this.raf);
    this.raf = 0;
    this.queue = [];
    this.displayStep = null;
    this.emit();
  }

  dispose() {
    this.stop();
  }

  private emit() {
    for (const listener of this.listeners) listener(this.displayStep, this.playing);
  }

  private ensure() {
    if (!this.ctx) {
      const ctx = new AudioContext();
      const master = ctx.createGain();
      master.gain.value = this.volume;
      const comp = ctx.createDynamicsCompressor();
      comp.threshold.value = -14;
      comp.knee.value = 16;
      comp.ratio.value = 3.2;
      comp.attack.value = 0.004;
      comp.release.value = 0.18;
      master.connect(comp);
      comp.connect(ctx.destination);
      this.ctx = ctx;
      this.master = master;
      this.noise = makeNoise(ctx);
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
    return this.ctx;
  }

  private schedule() {
    const ctx = this.ctx;
    if (!ctx || !this.playing) return;
    while (this.nextTime < ctx.currentTime + LOOKAHEAD) {
      const step = this.stepIndex;
      const when = this.nextTime;
      for (let track = 0; track < TRACK_COUNT; track++) {
        if (this.pattern[track]?.[step]) this.hit(track, when);
      }
      this.queue.push({ step, time: when });
      this.nextTime += stepDuration(step, this.bpm, this.swing);
      this.stepIndex = (step + 1) % STEPS;
    }
  }

  private pump = () => {
    if (!this.playing || !this.ctx) return;
    const now = this.ctx.currentTime;
    let step: number | null = null;
    while (this.queue.length && this.queue[0].time <= now + 0.02) {
      step = this.queue.shift()!.step;
    }
    if (step !== null && step !== this.displayStep) {
      this.displayStep = step;
      this.emit();
    }
    this.raf = requestAnimationFrame(this.pump);
  };

  private hit(track: number, time: number) {
    if (track === 0) this.kick(time);
    else if (track === 1) this.snare(time);
    else if (track === 2) this.hat(time);
    else this.clap(time);
  }

  private kick(time: number) {
    const ctx = this.ctx!;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "sine";
    osc.frequency.setValueAtTime(164, time);
    osc.frequency.exponentialRampToValueAtTime(48, time + 0.1);
    gain.gain.setValueAtTime(0.0001, time);
    gain.gain.exponentialRampToValueAtTime(0.95, time + 0.006);
    gain.gain.exponentialRampToValueAtTime(0.001, time + 0.4);
    osc.connect(gain);
    gain.connect(this.master!);
    osc.start(time);
    osc.stop(time + 0.42);

    const click = ctx.createOscillator();
    const clickGain = ctx.createGain();
    click.type = "triangle";
    click.frequency.setValueAtTime(980, time);
    clickGain.gain.setValueAtTime(0.16, time);
    clickGain.gain.exponentialRampToValueAtTime(0.001, time + 0.016);
    click.connect(clickGain);
    clickGain.connect(this.master!);
    click.start(time);
    click.stop(time + 0.03);
  }

  private snare(time: number) {
    const ctx = this.ctx!;
    const noise = ctx.createBufferSource();
    noise.buffer = this.noise;
    const highpass = ctx.createBiquadFilter();
    highpass.type = "highpass";
    highpass.frequency.value = 1600;
    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.62, time);
    gain.gain.exponentialRampToValueAtTime(0.001, time + 0.18);
    noise.connect(highpass);
    highpass.connect(gain);
    gain.connect(this.master!);
    noise.start(time);
    noise.stop(time + 0.2);

    const body = ctx.createOscillator();
    const bodyGain = ctx.createGain();
    body.type = "triangle";
    body.frequency.setValueAtTime(196, time);
    body.frequency.exponentialRampToValueAtTime(130, time + 0.08);
    bodyGain.gain.setValueAtTime(0.4, time);
    bodyGain.gain.exponentialRampToValueAtTime(0.001, time + 0.12);
    body.connect(bodyGain);
    bodyGain.connect(this.master!);
    body.start(time);
    body.stop(time + 0.14);
  }

  private hat(time: number) {
    const ctx = this.ctx!;
    const bus = ctx.createGain();
    bus.gain.value = 0.5;
    const highpass = ctx.createBiquadFilter();
    highpass.type = "highpass";
    highpass.frequency.value = 7000;
    const band = ctx.createBiquadFilter();
    band.type = "bandpass";
    band.frequency.value = 10000;
    band.Q.value = 0.7;
    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.9, time);
    gain.gain.exponentialRampToValueAtTime(0.001, time + 0.05);
    bus.connect(highpass);
    highpass.connect(band);
    band.connect(gain);
    gain.connect(this.master!);

    for (const ratio of [2, 3, 4.16, 5.43, 6.79, 8.21]) {
      const osc = ctx.createOscillator();
      osc.type = "square";
      osc.frequency.value = 40 * ratio;
      osc.connect(bus);
      osc.start(time);
      osc.stop(time + 0.07);
    }

    const noise = ctx.createBufferSource();
    noise.buffer = this.noise;
    const noiseHighpass = ctx.createBiquadFilter();
    noiseHighpass.type = "highpass";
    noiseHighpass.frequency.value = 8000;
    const noiseGain = ctx.createGain();
    noiseGain.gain.setValueAtTime(0.4, time);
    noiseGain.gain.exponentialRampToValueAtTime(0.001, time + 0.04);
    noise.connect(noiseHighpass);
    noiseHighpass.connect(noiseGain);
    noiseGain.connect(this.master!);
    noise.start(time);
    noise.stop(time + 0.06);
  }

  private clap(time: number) {
    const ctx = this.ctx!;
    const bursts = [
      { offset: 0, gain: 0.38, decay: 0.03 },
      { offset: 0.012, gain: 0.42, decay: 0.03 },
      { offset: 0.025, gain: 0.55, decay: 0.14 },
    ];
    for (const burst of bursts) {
      const at = time + burst.offset;
      const noise = ctx.createBufferSource();
      noise.buffer = this.noise;
      const band = ctx.createBiquadFilter();
      band.type = "bandpass";
      band.frequency.value = 1500;
      band.Q.value = 0.85;
      const highpass = ctx.createBiquadFilter();
      highpass.type = "highpass";
      highpass.frequency.value = 900;
      const gain = ctx.createGain();
      gain.gain.setValueAtTime(burst.gain, at);
      gain.gain.exponentialRampToValueAtTime(0.001, at + burst.decay);
      noise.connect(band);
      band.connect(highpass);
      highpass.connect(gain);
      gain.connect(this.master!);
      noise.start(at);
      noise.stop(at + burst.decay + 0.02);
    }
  }
}

function stepDuration(step: number, bpm: number, swing: number) {
  const sixteenth = 60 / bpm / 4;
  const pair = sixteenth * 2;
  const ratio = 0.5 + (swing / 100) * 0.25;
  return step % 2 === 0 ? pair * ratio : pair * (1 - ratio);
}

function makeNoise(ctx: AudioContext) {
  const length = ctx.sampleRate * 2;
  const buffer = ctx.createBuffer(1, length, ctx.sampleRate);
  const data = buffer.getChannelData(0);
  for (let i = 0; i < length; i++) data[i] = Math.random() * 2 - 1;
  return buffer;
}
