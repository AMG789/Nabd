export const STEPS = 16;
export const TRACK_COUNT = 4;

export const TRACKS = [
  { id: "kick", name: "باص", hint: "طبلة" },
  { id: "snare", name: "سنير", hint: "جانبي" },
  { id: "hat", name: "هات", hint: "مغلق" },
  { id: "perc", name: "إيقاع", hint: "تصفيق" },
] as const;

export type Pattern = boolean[][];

export const BPM_MIN = 60;
export const BPM_MAX = 180;
export const DEFAULT_BPM = 96;

export function emptyPattern(): Pattern {
  return Array.from({ length: TRACK_COUNT }, () => Array<boolean>(STEPS).fill(false));
}

function withSteps(steps: number[][]): Pattern {
  const pattern = emptyPattern();
  steps.forEach((row, track) => {
    for (const step of row) pattern[track][step] = true;
  });
  return pattern;
}

export function presetNabd(): Pattern {
  return withSteps([
    [0, 8, 10],
    [4, 12],
    [0, 2, 4, 6, 8, 10, 12, 14],
    [6, 14],
  ]);
}

export function presetHouse(): Pattern {
  return withSteps([
    [0, 4, 8, 12],
    [4, 12],
    [0, 2, 4, 6, 8, 10, 12, 14],
    [4, 12],
  ]);
}

export function presetTrap(): Pattern {
  return withSteps([
    [0, 3, 6, 10],
    [4, 12],
    [0, 2, 4, 6, 8, 10, 12, 13, 14, 15],
    [12, 14],
  ]);
}

export function presetBreak(): Pattern {
  return withSteps([
    [0, 3, 6, 10],
    [4, 7, 12, 15],
    [0, 2, 4, 5, 6, 8, 10, 12, 13, 14],
    [2, 11],
  ]);
}

export const PRESETS = [
  { id: "nabd", name: "نبض", build: presetNabd },
  { id: "house", name: "هاوس", build: presetHouse },
  { id: "trap", name: "تراب", build: presetTrap },
  { id: "break", name: "بريك", build: presetBreak },
] as const;

export function randomPattern(): Pattern {
  const pattern = emptyPattern();
  pattern[0][0] = true;
  for (const step of [3, 6, 7, 8, 10, 11, 14]) {
    if (Math.random() < 0.4) pattern[0][step] = true;
  }
  pattern[1][4] = true;
  pattern[1][12] = true;
  if (Math.random() < 0.45) pattern[1][Math.random() < 0.5 ? 7 : 15] = true;
  for (let step = 0; step < STEPS; step++) {
    const offbeat = step % 2 === 1;
    if (Math.random() < (offbeat ? 0.74 : 0.42)) pattern[2][step] = true;
  }
  pattern[2][0] = true;
  pattern[2][8] = true;
  for (let step = 0; step < STEPS; step++) {
    if (Math.random() < 0.2 && !pattern[0][step]) pattern[3][step] = true;
  }
  if (!pattern[3].some(Boolean)) pattern[3][6] = true;
  return pattern;
}

export function patternsEqual(a: Pattern, b: Pattern): boolean {
  return a.every((row, track) => row.every((on, step) => on === b[track]?.[step]));
}

export function isPattern(value: unknown): value is Pattern {
  if (!Array.isArray(value) || value.length !== TRACK_COUNT) return false;
  return value.every(
    (row) =>
      Array.isArray(row) &&
      row.length === STEPS &&
      row.every((cell) => typeof cell === "boolean"),
  );
}

const STORAGE_KEY = "nabd-kit-v1";

export type KitSettings = {
  pattern: Pattern;
  bpm: number;
  swing: number;
  volume: number;
};

export function loadKit(): KitSettings | null {
  if (typeof localStorage === "undefined") return null;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const data = JSON.parse(raw) as Partial<KitSettings>;
    if (!isPattern(data.pattern)) return null;
    const bpm = clamp(Number(data.bpm), BPM_MIN, BPM_MAX, DEFAULT_BPM);
    const swing = clamp(Number(data.swing), 0, 100, 0);
    const volume = clamp(Number(data.volume), 0, 100, 80);
    return { pattern: data.pattern, bpm, swing, volume };
  } catch {
    return null;
  }
}

export function saveKit(settings: KitSettings) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
  } catch {
    /* private mode / quota — the kit still plays */
  }
}

function clamp(value: number, min: number, max: number, fallback: number) {
  if (!Number.isFinite(value)) return fallback;
  return Math.min(max, Math.max(min, Math.round(value)));
}
