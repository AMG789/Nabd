import { useEffect, useRef, useState } from "react";
import { Play, Shuffle, Square, Trash2 } from "lucide-react";
import { DrumMachine as Engine } from "@/lib/drums/engine";
import {
  BPM_MAX,
  BPM_MIN,
  DEFAULT_BPM,
  PRESETS,
  TRACKS,
  emptyPattern,
  loadKit,
  patternsEqual,
  presetNabd,
  randomPattern,
  saveKit,
  type Pattern,
} from "@/lib/drums/pattern";

const GROUPS = [0, 1, 2, 3];

export function DrumMachine() {
  const engineRef = useRef<Engine | null>(null);
  const scrollerRef = useRef<HTMLDivElement>(null);
  const [pattern, setPattern] = useState<Pattern>(presetNabd);
  const [bpm, setBpm] = useState(DEFAULT_BPM);
  const [swing, setSwing] = useState(0);
  const [volume, setVolume] = useState(80);
  const [step, setStep] = useState<number | null>(null);
  const [playing, setPlaying] = useState(false);
  const [hydrated, setHydrated] = useState(false);

  const patternRef = useRef(pattern);
  const bpmRef = useRef(bpm);
  const swingRef = useRef(swing);
  const volumeRef = useRef(volume);
  patternRef.current = pattern;
  bpmRef.current = bpm;
  swingRef.current = swing;
  volumeRef.current = volume;

  useEffect(() => {
    const engine = new Engine();
    engineRef.current = engine;
    const saved = loadKit();
    if (saved) {
      setPattern(saved.pattern);
      setBpm(saved.bpm);
      setSwing(saved.swing);
      setVolume(saved.volume);
      engine.setPattern(saved.pattern);
      engine.setBpm(saved.bpm);
      engine.setSwing(saved.swing);
      engine.setVolume(saved.volume / 100);
    } else {
      engine.setPattern(patternRef.current);
      engine.setBpm(bpmRef.current);
      engine.setSwing(swingRef.current);
      engine.setVolume(volumeRef.current / 100);
    }
    const unsubscribe = engine.subscribe((nextStep, nextPlaying) => {
      setStep(nextStep);
      setPlaying(nextPlaying);
    });
    const onKey = (event: KeyboardEvent) => {
      if (event.code !== "Space") return;
      const target = event.target;
      if (target instanceof HTMLElement) {
        const tag = target.tagName;
        if (tag === "INPUT" || tag === "TEXTAREA" || tag === "BUTTON") return;
      }
      event.preventDefault();
      if (engine.playingNow) engine.stop();
      else engine.play();
    };
    window.addEventListener("keydown", onKey);
    setHydrated(true);
    return () => {
      unsubscribe();
      window.removeEventListener("keydown", onKey);
      engine.dispose();
      engineRef.current = null;
    };
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    saveKit({ pattern, bpm, swing, volume });
  }, [hydrated, pattern, bpm, swing, volume]);

  useEffect(() => {
    if (step === null) return;
    const scroller = scrollerRef.current;
    const marker = scroller?.querySelector<HTMLElement>(`[data-step-marker="${step}"]`);
    if (!scroller || !marker) return;
    if (scroller.scrollWidth <= scroller.clientWidth + 2) return;
    const mark = marker.getBoundingClientRect();
    const view = scroller.getBoundingClientRect();
    const lane = scroller.querySelector<HTMLElement>(".lane:not(.lane-spacer)");
    const laneLeft = lane?.getBoundingClientRect().left ?? view.right;
    const hiddenLeft = mark.left < view.left + 6;
    const hiddenRight = mark.right > laneLeft - 4;
    if (hiddenLeft || hiddenRight) {
      scroller.scrollLeft += mark.left - view.left - 16;
    }
  }, [step]);

  function commit(next: Pattern) {
    setPattern(next);
    engineRef.current?.setPattern(next);
  }

  function toggle(track: number, index: number) {
    const engine = engineRef.current;
    engine?.preview(track);
    const next = pattern.map((row) => row.slice());
    next[track][index] = !next[track][index];
    commit(next);
  }

  return (
    <main className="shell">
      <header className="top">
        <div>
          <div className="brand-row">
            <span
              className="led"
              data-live={playing}
              data-beat={playing && step !== null && step % 4 === 0}
              aria-hidden="true"
            />
            <h1 className="brand">نبض</h1>
          </div>
          <p className="lede">
            آلة طبول بشبكة من ست عشرة خطوة. اضغط الخانة لتسمعها وتثبّتها، واسم الآلة لتجربتها وحدها.
          </p>
        </div>
        <div className="readout" aria-live="polite">
          <span className="readout-label">{playing ? "الخطوة" : "متوقف"}</span>
          <span className="readout-num">{step === null ? "–" : String(step + 1).padStart(2, "0")}</span>
        </div>
      </header>

      <section className="chassis" aria-label="جهاز التسلسل">
        <div className="transport">
          <button
            type="button"
            className="btn btn-play"
            data-active={playing}
            aria-pressed={playing}
            onClick={() => engineRef.current?.play()}
          >
            <Play aria-hidden="true" size={18} fill="currentColor" />
            تشغيل
          </button>
          <button type="button" className="btn btn-stop" onClick={() => engineRef.current?.stop()}>
            <Square aria-hidden="true" size={16} fill="currentColor" />
            إيقاف
          </button>
          <span className="transport-gap" aria-hidden="true" />
          <button type="button" className="btn btn-ghost" onClick={() => commit(randomPattern())}>
            <Shuffle aria-hidden="true" size={18} />
            نمط عشوائي
          </button>
          <button type="button" className="btn btn-ghost" onClick={() => commit(emptyPattern())}>
            <Trash2 aria-hidden="true" size={18} />
            مسح النمط
          </button>
        </div>

        <div className="controls">
          <label className="control">
            <span className="control-name">السرعة</span>
            <input
              type="range"
              min={BPM_MIN}
              max={BPM_MAX}
              step={1}
              value={bpm}
              aria-valuemin={BPM_MIN}
              aria-valuemax={BPM_MAX}
              aria-valuenow={bpm}
              aria-label="السرعة"
              onChange={(event) => {
                const next = Number(event.target.value);
                setBpm(next);
                engineRef.current?.setBpm(next);
              }}
            />
            <span className="control-value">{bpm}</span>
          </label>

          <label className="control">
            <span className="control-name">السوينغ</span>
            <input
              type="range"
              min={0}
              max={100}
              step={1}
              value={swing}
              aria-valuemin={0}
              aria-valuemax={100}
              aria-valuenow={swing}
              aria-describedby="swing-note"
              aria-label="السوينغ"
              onChange={(event) => {
                const next = Number(event.target.value);
                setSwing(next);
                engineRef.current?.setSwing(next);
              }}
            />
            <span className="control-value">{swing}%</span>
            <span className="control-note" id="swing-note">
              يؤخّر الخطوات الزوجية عن النبض.
            </span>
          </label>

          <label className="control">
            <span className="control-name">الصوت</span>
            <input
              type="range"
              min={0}
              max={100}
              step={1}
              value={volume}
              aria-label="الصوت"
              onChange={(event) => {
                const next = Number(event.target.value);
                setVolume(next);
                engineRef.current?.setVolume(next / 100);
              }}
            />
            <span className="control-value">{volume}</span>
          </label>
        </div>

        <div className="presets" role="group" aria-label="أنماط جاهزة">
          {PRESETS.map((preset) => {
            const built = preset.build();
            const active = patternsEqual(pattern, built);
            return (
              <button
                key={preset.id}
                type="button"
                className="chip"
                data-active={active}
                aria-pressed={active}
                onClick={() => commit(built)}
              >
                {preset.name}
              </button>
            );
          })}
        </div>

        <p className="scroll-hint">اسحب الشبكة لرؤية الخطوات الست عشرة.</p>

        <div className="board-scroll" dir="ltr" ref={scrollerRef}>
          <div className="board">
            <div className="track" aria-hidden="true">
              <div className="groups">
                {GROUPS.map((group) => (
                  <div className="group" key={group}>
                    {GROUPS.map((offset) => {
                      const index = group * 4 + offset;
                      return (
                        <div
                          key={index}
                          className="ruler-cell"
                          data-step-marker={index}
                          data-beat={index % 4 === 0}
                          data-now={step === index}
                        >
                          {index + 1}
                        </div>
                      );
                    })}
                  </div>
                ))}
              </div>
              <div className="lane lane-spacer" />
            </div>

            {TRACKS.map((track, trackIndex) => (
              <div className="track" key={track.id}>
                <div className="groups">
                  {GROUPS.map((group) => (
                    <div className="group" key={group} role="group" aria-label={`${track.name} ${group + 1}`}>
                      {GROUPS.map((offset) => {
                        const index = group * 4 + offset;
                        const on = pattern[trackIndex][index];
                        return (
                          <button
                            key={index}
                            type="button"
                            className="pad"
                            data-on={on}
                            data-now={step === index}
                            data-beat={index % 4 === 0}
                            aria-pressed={on}
                            aria-label={`${track.name}، الخطوة ${index + 1}${on ? "، مفعّلة" : ""}`}
                            onClick={() => toggle(trackIndex, index)}
                          />
                        );
                      })}
                    </div>
                  ))}
                </div>
                <button
                  type="button"
                  className="lane"
                  dir="rtl"
                  onClick={() => engineRef.current?.preview(trackIndex)}
                  aria-label={`جرّب ${track.name}`}
                >
                  <span className="lane-name">{track.name}</span>
                  <span className="lane-hint">{track.hint}</span>
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
}
